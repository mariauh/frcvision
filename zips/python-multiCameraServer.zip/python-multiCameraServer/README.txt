=======================
Building locally on rPi
=======================

1) Copy multiCameraServer.py and runCamera to /home/pi
2) Run "./runInteractive" in /home/pi or "sudo svc -t /service/camera" to
   restart service.


===================
Building on desktop
===================

1) Copy multiCameraServer.py and runCamera to /home/pi on the Pi
2) On the Pi, run "./runInteractive" in /home/pi or
   "sudo svc -t /service/camera" to restart service.

